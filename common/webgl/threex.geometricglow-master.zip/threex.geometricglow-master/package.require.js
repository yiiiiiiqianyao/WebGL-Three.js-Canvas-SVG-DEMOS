define( [ './threex.dilategeometry.js'
	, './threex.atmospherematerial.js'
	, './threex.geometricglowmesh.js'
	, './threex.atmospherematerialdatgui.js'
	], function(){
});
